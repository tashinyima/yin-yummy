package com.example.loginui

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val onClickListener = button.setOnClickListener {
            it:View!
            if (editTextTextEmailAddress.text.isNullOrBlank() && editTextTextPassword.text.isNullOrBlank())
                Toast.makeText(this, "Please fill the required field", Toast.LENGTH_SHORT).show()
        }
        else{
            Toast.makeText(
                this,
                "${editTextTextEmailAddress.text} is logged in!!",
                Toast.LENGTH_SHORT
            ).show()
        }

        }
    }
};